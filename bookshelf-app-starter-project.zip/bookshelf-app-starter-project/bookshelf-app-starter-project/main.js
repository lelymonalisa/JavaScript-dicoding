const STORAGE_KEY = 'BOOKSHELF_APPS';

const generateId = () => +new Date();

const getBooks = () => {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
};

const saveBooks = (books) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
};

const createBookElement = (book) => {
  const { id, title, author, year, isComplete } = book;

  const bookItem = document.createElement('div');
  bookItem.setAttribute('data-bookid', id);
  bookItem.setAttribute('data-testid', 'bookItem');

  const bookTitle = document.createElement('h3');
  bookTitle.setAttribute('data-testid', 'bookItemTitle');
  bookTitle.textContent = title;

  const bookAuthor = document.createElement('p');
  bookAuthor.setAttribute('data-testid', 'bookItemAuthor');
  bookAuthor.textContent = `Penulis: ${author}`;

  const bookYear = document.createElement('p');
  bookYear.setAttribute('data-testid', 'bookItemYear');
  bookYear.textContent = `Tahun: ${year}`;

  const buttonContainer = document.createElement('div');

  const toggleButton = document.createElement('button');
  toggleButton.setAttribute('data-testid', 'bookItemIsCompleteButton');
  toggleButton.textContent = isComplete ? 'Belum selesai dibaca' : 'Selesai dibaca';
  toggleButton.addEventListener('click', () => toggleBookStatus(id));

  const deleteButton = document.createElement('button');
  deleteButton.setAttribute('data-testid', 'bookItemDeleteButton');
  deleteButton.textContent = 'Hapus Buku';
  deleteButton.addEventListener('click', () => deleteBook(id));

  const editButton = document.createElement('button');
  editButton.setAttribute('data-testid', 'bookItemEditButton');
  editButton.textContent = 'Edit Buku';
  editButton.addEventListener('click', () => openEditModal(id));

  buttonContainer.append(toggleButton, deleteButton, editButton);
  bookItem.append(bookTitle, bookAuthor, bookYear, buttonContainer);

  return bookItem;
};

const renderBooks = (query = '') => {
  const incompleteList = document.getElementById('incompleteBookList');
  const completeList = document.getElementById('completeBookList');

  incompleteList.innerHTML = '';
  completeList.innerHTML = '';

  const books = getBooks();
  const filtered = query
    ? books.filter((b) => b.title.toLowerCase().includes(query.toLowerCase()))
    : books;

  for (const book of filtered) {
    const el = createBookElement(book);
    if (book.isComplete) {
      completeList.append(el);
    } else {
      incompleteList.append(el);
    }
  }
};

const toggleBookStatus = (id) => {
  const books = getBooks();
  const book = books.find((b) => b.id === id);
  if (book) {
    book.isComplete = !book.isComplete;
    saveBooks(books);
    renderBooks();
  }
};

const deleteBook = (id) => {
  if (!confirm('Yakin ingin menghapus buku ini?')) return;
  const books = getBooks().filter((b) => b.id !== id);
  saveBooks(books);
  renderBooks();
};

const openEditModal = (id) => {
  const book = getBooks().find((b) => b.id === id);
  if (!book) return;

  document.getElementById('editBookId').value = book.id;
  document.getElementById('editBookTitle').value = book.title;
  document.getElementById('editBookAuthor').value = book.author;
  document.getElementById('editBookYear').value = book.year;
  document.getElementById('editBookIsComplete').checked = book.isComplete;

  document.getElementById('editModal').style.display = 'flex';
};

document.addEventListener('DOMContentLoaded', () => {
  // --- Add Book Form ---
  const bookForm = document.getElementById('bookForm');
  const isCompleteCheckbox = document.getElementById('bookFormIsComplete');
  const submitButton = document.getElementById('bookFormSubmit');
  const submitSpan = submitButton.querySelector('span');

  isCompleteCheckbox.addEventListener('change', () => {
    submitSpan.textContent = isCompleteCheckbox.checked
      ? 'Selesai dibaca'
      : 'Belum selesai dibaca';
  });

  bookForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const book = {
      id: generateId(),
      title: document.getElementById('bookFormTitle').value,
      author: document.getElementById('bookFormAuthor').value,
      year: Number(document.getElementById('bookFormYear').value),
      isComplete: isCompleteCheckbox.checked,
    };
    const books = getBooks();
    books.push(book);
    saveBooks(books);
    renderBooks();
    bookForm.reset();
    submitSpan.textContent = 'Belum selesai dibaca';
  });

  // --- Search Form ---
  const searchForm = document.getElementById('searchBook');
  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = document.getElementById('searchBookTitle').value;
    renderBooks(query);
  });

  // --- Edit Modal Form ---
  const editForm = document.getElementById('editBookForm');
  editForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const id = Number(document.getElementById('editBookId').value);
    const books = getBooks();
    const book = books.find((b) => b.id === id);
    if (book) {
      book.title = document.getElementById('editBookTitle').value;
      book.author = document.getElementById('editBookAuthor').value;
      book.year = Number(document.getElementById('editBookYear').value);
      book.isComplete = document.getElementById('editBookIsComplete').checked;
      saveBooks(books);
      renderBooks();
    }
    document.getElementById('editModal').style.display = 'none';
  });

  document.getElementById('editBookCancel').addEventListener('click', () => {
    document.getElementById('editModal').style.display = 'none';
  });

  // Close modal when clicking overlay
  document.getElementById('editModal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('editModal')) {
      document.getElementById('editModal').style.display = 'none';
    }
  });

  // --- Initial render ---
  renderBooks();
});
